/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresa el primer número: ");
        double numero1 = sc.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        double numero2 = sc.nextDouble();

        System.out.print("Ingrese la operación que desea realizar: ");
        String operacion = sc.next();

        if (operacion.equals("+")) {
            System.out.println("Resultado: " + (numero1 + numero2));
        } else {
            if (operacion.equals("-")) {
                System.out.println("Resultado: " + (numero1 - numero2));
            } else {
                if (operacion.equals("*")) {
                    System.out.println("Resultado: " + (numero1 * numero2));
                } else {
                    if (operacion.equals("/")) {
                        if (numero2 != 0) {
                            System.out.println("Resultado: " + (numero1 / numero2));
                        } else {
                            System.out.println("No se puede dividir entre cero");
                        }
                    } else {
                        System.out.println("Operación no válida");
                    }
                }
            }
        }

        sc.close();
    }
}