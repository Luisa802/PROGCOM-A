/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el primer lado: ");
        double a = sc.nextDouble();

        System.out.print("Ingrese el segundo lado: ");
        double b = sc.nextDouble();

        System.out.print("Ingrese el tercer lado: ");
        double c = sc.nextDouble();

        if (a + b > c && a + c > b && b + c > a) {

            if (a == b && b == c) {
                System.out.println("El triangulo es equilatero");
            } else {
                if (a == b || a == c || b == c) {
                    System.out.println("El triangulo es isosceles");
                } else {
                    System.out.println("El triangulo es escaleno");
                }
            }

        } else {
            System.out.println("Los lados ingresados no forman un triangulo");
        }

        sc.close();
    }
}