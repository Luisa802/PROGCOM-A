import java.util.*;
public class añobisiesto3

{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
        
        System.out.print("Ingrese el año: ");
        int año = Leer.nextInt();
       
       System.out.println (año % 4 == 0 ? "El año ingresado es bisiesto" : año % 400 == 0 ? "El año es bisiesto"
       : "El año ingresado no es bisiesto");
}}