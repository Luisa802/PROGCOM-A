import java.util.Scanner;

public class Semanas {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un número del 1 al 7 para determinar qué día es: ");
        int num = scanner.nextInt();

        String resp = (num == 1) ? "El día es Lunes"
                : (num == 2) ? "El día es Martes"
                : (num == 3) ? "El día es Miércoles"
                : (num == 4) ? "El día es Jueves"
                : (num == 5) ? "El día es Viernes"
                : (num == 6) ? "El día es Sábado"
                : "El día es Domingo";

        System.out.println(resp);

        scanner.close();
    }
}