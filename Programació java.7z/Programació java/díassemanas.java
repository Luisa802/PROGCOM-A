/******************************************************************************
Escribe un programa que determine el día de la semana según un número (1-7).
*******************************************************************************/
import java.util.Scanner;

public class díassemanas {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un número del 1 al 7 para determinar qué día es: ");
        int num = scanner.nextInt();

        if (num == 1) {
            System.out.println("El día es Lunes");
        } else if (num == 2) {
            System.out.println("El día es Martes");
        } else if (num == 3) {
            System.out.println("El día es Miércoles");
        } else if (num == 4) {
            System.out.println("El día es Jueves");
        } else if (num == 5) {
            System.out.println("El día es Viernes");
        } else if (num == 6) {
            System.out.println("El día es Sábado");
        } else {
            System.out.println("El día es Domingo");
        }

        scanner.close();
    }
}