import java.util.Scanner;

public class nota {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su nota: ");
        int nota = scanner.nextInt();

        String resp = (nota >= 90) ? "Su nota tiene una A 😄"
                : (nota >= 80) ? "Su nota tiene una B 😊"
                : (nota >= 70) ? "Su nota tiene una C 🙂"
                : (nota >= 60) ? "Su nota tiene una D 🙁"
                : "Su nota tiene una F 😖";

        System.out.println(resp);

        scanner.close();
    }
}