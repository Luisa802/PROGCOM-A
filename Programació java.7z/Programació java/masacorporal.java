/******************************************************************************
Escribe un programa que calcule el índice de masa corporal (IMC) y determine la categoría (bajo peso, normal, sobrepeso, obesidad). Al final, el programa debe imprimir: el nombre del usuario, su categoría y una breve descripción de lo que debe hacer de acuerdo a su categoría.

*******************************************************************************/
import java.util.Scanner;

public class masacorporal {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese su peso en kg: ");
        double peso = scanner.nextDouble();
        
        System.out.print("Ingrese su estatura en metros: ");
        double altura = scanner.nextDouble();
        
        double imc = peso / (altura * altura);
        
        System.out.printf("Este es su IMC %.2f%n", imc);
        
        if (imc < 18.5) {
            System.out.println("Tiene bajo peso");
        } else if (imc >= 18.5 && imc < 24.9) {
            System.out.println("Tiene peso normal");
        } else if (imc >= 25 && imc < 29.9) {
            System.out.println("Tiene sobrepeso");
        } else {
            System.out.println("Tiene obesidad");
        }
        
        scanner.close();
    }
}