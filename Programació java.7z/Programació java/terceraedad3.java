import java.util.*;
public class terceraedad3
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
       
        System.out.println("Ingresa tu edad: ");
        int edad = Leer.nextInt();
    
      
        System.out.println(edad >= 70? "Usted tiene prioridad en la fila por pertenecer a la tercera edad."
        : "Por favor, espere su turno en la fila general.");

}}