/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresa el primer número: ");
        double numero1 = sc.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        double numero2 = sc.nextDouble();

        System.out.print("Ingrese la operación que desea realizar: ");
        String operacion = sc.next();

        String resp =
                operacion.equals("+") ? "Resultado: " + (numero1 + numero2) :
                operacion.equals("-") ? "Resultado: " + (numero1 - numero2) :
                operacion.equals("*") ? "Resultado: " + (numero1 * numero2) :
                operacion.equals("/") && numero2 != 0 ? "Resultado: " + (numero1 / numero2) :
                operacion.equals("/") && numero2 == 0 ? "No se puede dividir entre cero" :
                "Operación no válida";

        System.out.println(resp);

        sc.close();
    }
}