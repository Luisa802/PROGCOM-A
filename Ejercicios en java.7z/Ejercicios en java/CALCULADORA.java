/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresa el primer número: ");
        double numero1 = sc.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        double numero2 = sc.nextDouble();

        System.out.print("Ingrese la operación que desea realizar (+, -, *, /): ");
        String operacion = sc.next();

        if (operacion.equals("+")) {
            double resultado = numero1 + numero2;
            System.out.println("El resultado es: " + resultado);

        } else if (operacion.equals("-")) {
            double resultado = numero1 - numero2;
            System.out.println("El resultado es: " + resultado);

        } else if (operacion.equals("*")) {
            double resultado = numero1 * numero2;
            System.out.println("El resultado es: " + resultado);

        } else if (operacion.equals("/")) {
            if (numero2 != 0) {
                double resultado = numero1 / numero2;
                System.out.println("El resultado es: " + resultado);
            } else {
                System.out.println("No se puede dividir entre cero");
            }

        } else {
            System.out.println("Operación no válida");
        }

        sc.close();
    }
}