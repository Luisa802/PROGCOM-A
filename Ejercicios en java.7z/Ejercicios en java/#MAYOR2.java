/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingresa el primer número: ");
        double numero1 = entrada.nextDouble();

        System.out.print("Ingresa el segundo número: ");
        double numero2 = entrada.nextDouble();

        System.out.print("Ingresa el tercer número: ");
        double numero3 = entrada.nextDouble();

        double mayor = numero1;

        if (numero2 > mayor) {
            mayor = numero2;
        } else {
            mayor = mayor;
        }

        if (numero3 > mayor) {
            mayor = numero3;
        } else {
            mayor = mayor;
        }

        System.out.println("El número mayor es: " + mayor);

        entrada.close();
    }
}