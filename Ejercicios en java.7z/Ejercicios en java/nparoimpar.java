import java.util.*;
public class nparoimpar
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
        
        System.out.print("Ingrese un número: ");
        int numero = Leer.nextInt();
        
        if (numero % 2 == 0) {System.out.println("El número es par");}
        else if (numero % 2 != 0) { System.out.println("El número es impar"); }
        }
    }
