import java.util.*;
public class nparoimpar3
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
        
        System.out.print("Ingrese un número: ");
        int numero = Leer.nextInt();
       
        String resp = (numero % 2 == 0) ? "El número es par" : "El número es impar";
        
        System.out.println(resp);
    }}