/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Ecuación cuadrática ax^2 + bx + c = 0");

        System.out.print("Ingrese el valor de a: ");
        double a = sc.nextDouble();

        System.out.print("Ingrese el valor de b: ");
        double b = sc.nextDouble();

        System.out.print("Ingrese el valor de c: ");
        double c = sc.nextDouble();

        if (a == 0) {
            System.out.println("El valor de 'a' no puede ser cero en la ecuación");
        } else {

            double discriminante = (b * b) - (4 * a * c);

            if (discriminante > 0) {

                double x1 = (-b + Math.sqrt(discriminante)) / (2 * a);
                double x2 = (-b - Math.sqrt(discriminante)) / (2 * a);

                System.out.println("Las soluciones son:");
                System.out.println("x1 = " + x1);
                System.out.println("x2 = " + x2);

            } else if (discriminante == 0) {

                double x = -b / (2 * a);
                System.out.println("La única solución es:");
                System.out.println("x = " + x);

            } else {

                System.out.println("No tiene soluciones reales");
            }
        }

        sc.close();
    }
}