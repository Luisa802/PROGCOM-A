/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ecuación cuadrática ax^2 + bx + c = 0");

        System.out.print("Ingrese a: ");
        double a = sc.nextDouble();

        System.out.print("Ingrese b: ");
        double b = sc.nextDouble();

        System.out.print("Ingrese c: ");
        double c = sc.nextDouble();

        double d = (a != 0) ? (b * b - 4 * a * c) : 0;

        String resp = (a == 0) ? "No es una ecuación cuadrática"
                     : (d < 0) ? "No tiene soluciones reales"
                     : "Las soluciones son:";

        System.out.println(resp);

        if (a != 0 && d >= 0) {
            double x1 = (-b + Math.sqrt(d)) / (2 * a);
            double x2 = (-b - Math.sqrt(d)) / (2 * a);

            System.out.println("x1 = " + x1);
            System.out.println("x2 = " + x2);
        }

        sc.close();
    }
}