import java.util.Scanner;

public class lados {

    public static void lados(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el primer lado del triangulo: ");
        int lado1 = sc.nextInt();

        System.out.print("Ingrese el segundo lado del triangulo: ");
        int lado2 = sc.nextInt();

        System.out.print("Ingrese el tercer lado del triangulo: ");
        int lado3 = sc.nextInt();

        String resp = (lado1 == lado2 && lado2 == lado3)
                ? "Es un triangulo equilatero"
                : (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                    ? "Es un triangulo isosceles"
                    : "Es un triangulo escaleno";

        System.out.println(resp);

        sc.close();
    }
}