import java.util.*;
public class terceraedad2
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
       
        System.out.print("Por favor, ingresa tu edad: ");
        int edad = Leer.nextInt();
    
        if (edad >= 70) { System.out.println("Bienvenido/a, Usted tiene prioridad en la fila por pertenecer a la tercera edad.");}
        else {System.out.println("Hola, Por favor, espere su turno en la fila general.");}
}}