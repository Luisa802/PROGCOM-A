import java.util.*;
public class terceraedad
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
       
        System.out.print("Por favor, ingresa tu edad: ");
        int edad = Leer.nextInt();
        
        if (edad >= 70) { System.out.println("Hola, perteneces a la tercera edad. Tienes prioridad en la fila.");}
        else if (edad >= 18) {System.out.println("Hola, Usted es mayor de edad, por favor haga la fila regular.");}
        else {System.out.println("Hola, Eres menor de edad, por favor espera a tu tutor.");}
}}