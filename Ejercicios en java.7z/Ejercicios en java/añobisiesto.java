import java.util.*;
public class añobisiesto
{
    public static void main(String[] args){
        Scanner Leer = new Scanner(System.in);
        
        System.out.print("Ingrese el año: ");
        int año = Leer.nextInt();
       
        if (año % 400 == 0) {System.out.println("El año es bisiesto"); }
        else if (año % 4 == 0 && año % 100 != 0) { System.out.println("El año ingresado es bisiesto"); }
        else { System.out.println("El año ingresado no es bisiesto"); }
    }
    
}
