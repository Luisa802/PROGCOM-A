import java.util.Scanner;

public class imc {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su peso en kg: ");
        double peso = scanner.nextDouble();

        System.out.print("Ingrese su estatura en metros: ");
        double altura = scanner.nextDouble();

        double imc = peso / (altura * altura);

        System.out.printf("Este es su IMC %.2f%n", imc);

        String resp = (imc < 18.5) ? "Tiene bajo peso"
                : (imc >= 18.5 && imc < 24.9) ? "Tiene peso normal"
                : (imc >= 25 && imc < 29.9) ? "Tiene sobrepeso"
                : "Tiene obesidad";

        System.out.println(resp);

        scanner.close();
    }
}