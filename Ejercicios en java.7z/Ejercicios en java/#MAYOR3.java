/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        double numero1 = entrada.nextDouble();

        System.out.print("Ingrese el segundo número: ");
        double numero2 = entrada.nextDouble();

        System.out.print("Ingrese el tercer número: ");
        double numero3 = entrada.nextDouble();

        double mayor = (numero1 > numero2) ? numero1 : numero2;
        mayor = (mayor > numero3) ? mayor : numero3;

        System.out.println("El número mayor es: " + mayor);

        entrada.close();
    }
}