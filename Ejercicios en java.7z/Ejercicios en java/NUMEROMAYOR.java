/******************************************************************************

Crea un programa que resuelva una ecuación cuadrática (ax² + bx + c = 0) pidiendo los valores de a, b y c.
*******************************************************************************/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Ingresa el primer número: ");
        double numero1 = entrada.nextDouble();
        
        System.out.print("Ingresa el segundo número: ");
        double numero2 = entrada.nextDouble();
        
        System.out.print("Ingresa el tercer número: ");
        double numero3 = entrada.nextDouble();
        
        if (numero1 > numero2 && numero1 > numero3) {
            System.out.println("El número mayor es: " + numero1);
        } 
        else if (numero2 > numero1 && numero2 > numero3) {
            System.out.println("El número mayor es: " + numero2);
        } 
        else if (numero3 > numero1 && numero3 > numero2) {
            System.out.println("El número mayor es: " + numero3);
        } 
        else {
            System.out.println("Hay números iguales o los tres son iguales");
        }
        
        entrada.close();
    }
}