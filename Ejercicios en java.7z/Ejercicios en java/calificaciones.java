/******************************************************************************
Crea un programa que determine la calificación en letras (A, B, C, D, F) según una nota numérica (0-100).

*******************************************************************************/
import java.util.Scanner;

public class calificaciones {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su nota: ");
        int nota = scanner.nextInt();

        if (nota >= 90) {
            System.out.println("Su nota tiene una A 😄");
        } else if (nota >= 80) {
            System.out.println("Su nota tiene una B 😊");
        } else if (nota >= 70) {
            System.out.println("Su nota tiene una C 🙂");
        } else if (nota >= 60) {
            System.out.println("Su nota tiene una D 🙁");
        } else {
            System.out.println("Su nota tiene una F 😖");
        }

        scanner.close();
    }
}